require 'duper_clock/clock'
require 'duper_clock/ticker'
require 'test/unit'