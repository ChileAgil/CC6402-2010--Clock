require 'test_helper'

class ClockTest < Test::Unit::TestCase
  def test_the_truth
    assert true
  end
  
  def testIncrementoSegundo
	assert true
  end
end
