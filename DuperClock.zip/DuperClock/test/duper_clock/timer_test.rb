require 'test_helper'
require '../../lib/duper_clock/time_model'

class TimerTest < Test::Unit::TestCase
  def test_the_truth
    assert true
  end
  
  def test_increment_second
	myTime = TimeModel.new
	initialSeconds = myTime.seconds
	myTime.increment_second()
	finalSeconds = myTime.seconds
	result = finalSeconds - initialSeconds
	assert 1, result
  end
end