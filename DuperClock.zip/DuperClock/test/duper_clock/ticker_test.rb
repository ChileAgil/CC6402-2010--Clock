require 'test_helper'

class TickerTest < Test::Unit::TestCase
  def test_the_truth
    # ticker = DuperClock::Ticker.new 
    # clock = DuperClock::Clock.new
    assert true
  end
end
