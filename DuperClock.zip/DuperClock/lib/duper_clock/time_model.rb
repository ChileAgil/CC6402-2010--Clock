module DuperClock
	class TimeModel
		def initialize
			@values = {:minutes => 0, :seconds => 0, :hours => 0}
		end
		
		def increment_seconds
			if @values[:seconds] == 59
				@values[:seconds] = 0
				@values[:minutes] += 1
			else
				@values[:seconds] += 1
		end
		
		def seconds
			@values[:seconds]
		end
	end
end