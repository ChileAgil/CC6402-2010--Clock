module DuperClock
  class Clock
  end
end
