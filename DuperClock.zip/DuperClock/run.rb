$: << File.expand_path('../lib', __FILE__)

require 'duper_clock'
DuperClock::Window.new.main_loop
